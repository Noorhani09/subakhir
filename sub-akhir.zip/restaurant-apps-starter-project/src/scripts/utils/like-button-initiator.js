import FavoriteMenuIdb from '../data/favorite-menu-idb';
import { createLikeButton, createLikedButton } from '../views/templates/template-creator';

const LikeButtonInitator = {
  async init({ likeButtonContainer, menu }) {
    this._likeButtonContainer = likeButtonContainer;
    this._menu = menu;
    await this._renderButton();
  },

  async _renderButton() {
    const { id } = this._menu;
    if (await this._isMenuExist(id)) {
      this._renderLiked();
    } else {
      this._renderLike();
    }
  },

  async _isMenuExist(id) {
    const menu = await FavoriteMenuIdb.getMenu(id);
    return !!menu;
  },

  _renderLike() {
    this._likeButtonContainer.innerHTML = createLikeButton();
    const likeButton = document.querySelector('#btn-like');
    likeButton.addEventListener('click', async () => {
      await FavoriteMenuIdb.putMenu(this._menu);
      this._renderButton();
    });

    likeButton.addEventListener('keydown', async (event) => {
      if (event.key === 'Enter') {
        await FavoriteMenuIdb.putMenu(this._menu);
        this._renderButton();
      }
    });
  },

  _renderLiked() {
    this._likeButtonContainer.innerHTML = createLikedButton();
    const likeButton = document.querySelector('#btn-like');
    likeButton.addEventListener('click', async () => {
      await FavoriteMenuIdb.deleteMenu(this._menu.id);
      this._renderButton();
    });

    likeButton.addEventListener('keydown', async (event) => {
      if (event.key === 'Enter') {
        await FavoriteMenuIdb.deleteMenu(this._menu.id);
        this._renderButton();
      }
    });
  },
};

export default LikeButtonInitator;
