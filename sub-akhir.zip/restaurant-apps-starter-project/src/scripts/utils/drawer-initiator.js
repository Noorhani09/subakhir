const DrawerInitiator = {
  init({ button, drawer }) {
    button.addEventListener('click', (event) => {
      drawer.classList.toggle('open');
      event.stopPropagation();
    });

    button.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        drawer.classList.toggle('open');
        event.stopPropagation();
      }
    });
  },
};

export default DrawerInitiator;
