import CONFIG from '../globals/config';

class SumberData {
  static async listRestaurant() {
    const response = await fetch(`${CONFIG.BASE_URL}list`);
    const responseJson = await response.json();
    return responseJson.restaurants;
  }

  static async detailRestaurant(id) {
    const response = await fetch(`${CONFIG.BASE_URL}detail/${id}`);
    const responseJson = await response.json();
    return responseJson.restaurant;
  }
}

export default SumberData;
