import FavoriteMenuIdb from '../../data/favorite-menu-idb';
import CONFIG from '../../globals/config';

const Home = {
  async render() {
    return `
        <h1>Restaurant Favorite</h1>
    <div id="restaurants-list"></div>
      `;
  },

  async afterRender() {
    const menu = await FavoriteMenuIdb.getAllMenu();
    if (menu.length === 0) {
      const restaurantListElement = document.querySelector('.content');
      restaurantListElement.innerHTML += `
          <span>Belum ada restoran yang disukai</span>
        `;
    } else {
      const restaurantsList = document.getElementById('restaurants-list');

      menu.forEach((restaurant) => {
        const restaurantDiv = document.createElement('div');
        restaurantDiv.className = 'restaurant';

        const restaurantImage = document.createElement('img');
        restaurantImage.src = CONFIG.BASE_IMAGE_SMALL_URL + restaurant.pictureId;
        restaurantImage.setAttribute('alt', `Image${restaurant.name}`);

        const restaurantCity = document.createElement('h4');
        restaurantCity.textContent = `Kota ${restaurant.city}`;
        restaurantCity.className = 'labelCity';

        const restaurantRating = document.createElement('h4');
        restaurantRating.textContent = `Rating: ${restaurant.rating}`;

        const restaurantName = document.createElement('h2');
        const restaurantLink = document.createElement('a');
        restaurantLink.textContent = restaurant.name;
        restaurantLink.href = `/#/detail/${restaurant.id}`;
        restaurantName.appendChild(restaurantLink);

        const restaurantDescription = document.createElement('p');
        restaurantDescription.textContent = `${restaurant.description.substring(0, 200)}...`;
        restaurantDiv.appendChild(restaurantImage);
        restaurantDiv.appendChild(restaurantCity);
        restaurantDiv.appendChild(restaurantRating);
        restaurantDiv.appendChild(restaurantName);
        restaurantDiv.appendChild(restaurantDescription);

        restaurantsList.appendChild(restaurantDiv);
      });
    }
  },
};

export default Home;
