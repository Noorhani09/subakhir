import SumberData from '../../data/sumberData';
import CONFIG from '../../globals/config';
import UrlParser from '../../routes/url-parser';
import LikeButtonInitator from '../../utils/like-button-initiator';

const Detail = {
  async render() {
    return `
    <h1>Detail Restaurant</h1>
    <div id="restaurant"></div>
    <div id="testimonials"></div> `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const item = await SumberData.detailRestaurant(url.id);
    console.log(item);
    const itemContainer = document.querySelector('#restaurant');

    // Create elements
    const itemDetail = document.createElement('div');
    itemDetail.className = 'item-detail';

    const itemNameAndLike = document.createElement('div');
    itemNameAndLike.className = 'item-name-and-like';

    const btnLike = document.createElement('div');
    btnLike.id = 'likeContainer';

    const itemTitle = document.createElement('h3');
    itemTitle.className = 'item-title';
    itemTitle.textContent = item.name;

    itemNameAndLike.appendChild(btnLike);
    itemNameAndLike.appendChild(itemTitle);

    const itemImage = document.createElement('img');
    itemImage.className = 'item-image';
    itemImage.src = `${CONFIG.BASE_IMAGE_MEDIUM_URL}${item.pictureId} `;
    itemImage.crossOrigin = 'anonymous';
    itemImage.alt = item.name;

    const itemInfo = document.createElement('div');
    itemInfo.className = 'item-info';
    itemInfo.innerHTML = `
    <h4 class="item-info-title" > Information</h4 >
    <h5 class="item-info-subtitle">City</h5>
    <p class="item-info-text">${item.city}</p>
    <h5 class="item-info-subtitle">Address</h5>
    <p class="item-info-text">${item.address}</p>
    <h5 class="item-info-subtitle">Rating</h5>
    <p class="item-info-text">${item.rating}</p>
    <h5 class="item-info-subtitle">Categories</h5>
    <p class="item-info-text">${item.categories.map((category) => category.name).join(', ')}</p>
    <h5 class="item-info-subtitle">Foods</h5>
    <p class="item-info-text">${item.menus.foods.map((food) => food.name).join(', ')}</p>
    <h5 class="item-info-subtitle">Drinks</h5>
    <p class="item-info-text">${item.menus.drinks.map((drink) => drink.name).join(', ')}</p>
    <h5 class="item-info-subtitle">Description</h5>
    <p class="item-info-text">${item.description}</p>
    `;

    // Add more elements to itemInfo as needed...

    const itemReview = document.createElement('div');
    itemReview.className = 'item-review';

    itemDetail.appendChild(itemNameAndLike);
    itemDetail.appendChild(itemImage);
    itemDetail.appendChild(itemInfo);
    itemDetail.appendChild(itemReview);

    // Append itemDetail to itemContainer
    itemContainer.appendChild(itemDetail);

    const reviewContainer = document.querySelector('#testimonials');
    item.customerReviews.forEach((review) => {
      const testimonial = document.createElement('div');
      testimonial.className = 'testimonial';

      const testimonialContent = document.createElement('div');
      testimonialContent.className = 'testimonial-content';

      const description = document.createElement('p');
      description.className = 'description';
      description.textContent = review.review;

      const testimonialTitle = document.createElement('h3');
      testimonialTitle.className = 'testimonial-title';
      testimonialTitle.textContent = review.name;

      const post = document.createElement('span');
      post.className = 'post';
      post.textContent = review.date;

      testimonialContent.appendChild(testimonialTitle);
      testimonialContent.appendChild(post);
      testimonialContent.appendChild(description);

      testimonial.appendChild(testimonialContent);

      reviewContainer.appendChild(testimonial);
    });

    LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: item,
    });
  },

};

export default Detail;
