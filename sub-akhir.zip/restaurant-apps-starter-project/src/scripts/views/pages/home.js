import SumberData from '../../data/sumberData';
import CONFIG from '../../globals/config';

const Home = {

  async render() {
    return `
    <h1>Explore Restaurant</h1>
    <div id="restaurants-list"></div>
    `;
  },

  async afterRender() {
    try {
      const data = await SumberData.listRestaurant();
      const restaurantsList = document.getElementById('restaurants-list');

      data.forEach((restaurant) => {
        const restaurantDiv = document.createElement('div');
        restaurantDiv.className = 'restaurant';

        const restaurantImage = document.createElement('img');
        restaurantImage.setAttribute('data-src', `${CONFIG.BASE_IMAGE_SMALL_URL}${restaurant.pictureId}`);
        restaurantImage.setAttribute('alt', `Image${restaurant.name}`);
        restaurantImage.crossOrigin = 'anonymous';
        restaurantImage.className = 'lazyload';

        const restaurantCity = document.createElement('h4');
        restaurantCity.textContent = `Kota ${restaurant.city}`;
        restaurantCity.className = 'labelCity';

        const restaurantRating = document.createElement('h4');
        restaurantRating.textContent = `Rating: ${restaurant.rating}`;

        const restaurantName = document.createElement('h2');
        const restaurantLink = document.createElement('a');
        restaurantLink.textContent = restaurant.name;
        restaurantLink.href = `/#/detail/${restaurant.id}`;
        restaurantName.appendChild(restaurantLink);

        const restaurantDescription = document.createElement('p');
        restaurantDescription.textContent = `${restaurant.description.substring(0, 200)}...`;
        restaurantDiv.appendChild(restaurantImage);
        restaurantDiv.appendChild(restaurantCity);
        restaurantDiv.appendChild(restaurantRating);
        restaurantDiv.appendChild(restaurantName);
        restaurantDiv.appendChild(restaurantDescription);

        restaurantsList.appendChild(restaurantDiv);
      });
    } catch (error) {
      console.error('Gagal mengambil data:', error);
    }
  },
};

export default Home;
