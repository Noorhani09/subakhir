import FavoriteMenuIdb from '../src/scripts/data/favorite-menu-idb';
import LikeButtonInitator from '../src/scripts/utils/like-button-initiator';

describe('Unliking a Restaurant', () => {
  const addLikeButtonContainer = () => {
    document.body.innerHTML = '<div  id="likeContainer"></div>';
  };
  beforeEach(async () => {
    addLikeButtonContainer();
    await FavoriteMenuIdb.putMenu({ id: 1 });
  });
  afterEach(async () => {
    await FavoriteMenuIdb.deleteMenu(1);
  });
  it('should display unlike widget when the restaurant has been liked', async () => {
    await LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: {
        id: 1,
      },
    });
    expect(document.querySelector('[aria-label="Hapus dari favorite"]')).toBeDefined();
  });
  it('should not display like widget when the restaurant has been liked', async () => {
    await LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: {
        id: 1,
      },
    });
    expect(document.querySelector('[aria-label="Tambahkan ke favorite"]')).toBeFalsy();
  });
  it('should be able to remove liked restaurant from the list', async () => {
    await LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: {
        id: 1,
      },
    });

    document.querySelector('[aria-label="Hapus dari favorite"]').dispatchEvent(new Event('click'));
    expect(await FavoriteMenuIdb.getAllMenu()).toEqual([]);
  });
  it('should not throw error if the unliked restaurant is not in the list', async () => {
    await LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: {
        id: 1,
      },
    });
    await FavoriteMenuIdb.deleteMenu(1);
    document.querySelector('[aria-label="Hapus dari favorite"]').dispatchEvent(new Event('click'));
    expect(await FavoriteMenuIdb.getAllMenu()).toEqual([]);
  });
});
