import FavoriteMenuIdb from '../src/scripts/data/favorite-menu-idb';
import LikeButtonInitator from '../src/scripts/utils/like-button-initiator';

describe('Liking a Restaurant', () => {
  const addLikeButtonContainer = () => {
    document.body.innerHTML = '<div id="likeContainer"></div>';
  };
  beforeEach(() => {
    addLikeButtonContainer();
  });

  it('should show the like button when the restaurant has not been liked before', async () => {
    await LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: { id: 1 },
    });

    expect(document.querySelector('[aria-label="Tambahkan ke favorite"]')).toBeDefined();
  });

  it('should not show the unlike button when the restaurant has not been liked before', async () => {
    await LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: {
        id: 1,
      },
    });

    expect(document.querySelector('[aria-label="Hapus dari favorite"]')).toBeFalsy();
  });

  it('should be able to like the restaurant', async () => {
    await LikeButtonInitator.init({
      likeButtonContainer: document.querySelector('#likeContainer'),
      menu: {
        id: 1,
      },
    });

    document.querySelector('#btn-like').dispatchEvent(new Event('click'));

    const menu = await FavoriteMenuIdb.getMenu(1);
    expect(menu).toEqual({ id: 1 });
    await FavoriteMenuIdb.deleteMenu(1);
  });
});
