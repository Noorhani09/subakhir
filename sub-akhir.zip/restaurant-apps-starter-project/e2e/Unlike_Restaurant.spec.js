const assert = require('assert');

Feature('Unlike Restaurant');

Before(({ I }) => {
  I.amOnPage('/#/favorite');
});

Scenario('showing empty favorite restaurant', ({ I }) => {
  I.see('Belum ada restoran yang disukai', 'span');
});

Scenario('unliking one restaurant', async ({ I }) => {
  I.see('Belum ada restoran yang disukai', 'span');

  I.amOnPage('');

  I.waitForElement('.restaurant', 5);

  const firstRestaurantTitle = await I.grabTextFrom(locate('.restaurant').first().find('h2'));

  I.click(locate('.restaurant').first().find('a'));

  I.seeElement('#btn-like');

  I.click('#btn-like');

  I.amOnPage('/#/favorite');

  I.seeElement('.restaurant');

  const likedRestaurantTitle = await I.grabTextFrom('.restaurant h2');

  assert.strictEqual(firstRestaurantTitle, likedRestaurantTitle);

  I.click(locate('.restaurant').first().find('a'));

  I.seeElement('#btn-like');
  I.click('#btn-like');

  I.amOnPage('/#/favorite');
  I.see('Belum ada restoran yang disukai', 'span');
});
